export class Parts{

    init() {

    }


}
