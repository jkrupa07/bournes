export class App {
  init() {
    
  }
}
